create table user
(
    user_id  varchar(16) not null,
    name     varchar(32) not null,
    password varchar(64) not null,
    constraint table_name_user_id_uindex
        unique (user_id)
);

alter table user
    add primary key (user_id);

INSERT INTO user_info_update.user (user_id, name, password) VALUES ('bob', 'Bob Builder', 'bob4apples');